"""Warehouse ingestion package."""
